# gameplay.py
import random
class Gameplay:
    def __init__(self, rounds, user_cards):
        self.rounds = rounds
        self.user_points = 0
        self.bot_points = 0
        self.current_round = 1
        self.user_cards = user_cards
        self.user_bids = []
        self.bot_bids = []
        self.drawn_cards = []
        self.card_points = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
    def draw_card(self):
        diamonds = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        available_cards = [card for card in diamonds if card not in self.drawn_cards]
        if available_cards:
            card = random.choice(available_cards)
            self.drawn_cards.append(card)
            return card
        else:
            return None
        
    def determine_winner(self, user_bid, bot_bid, prize_card):
        if self.card_points[user_bid] > self.card_points[bot_bid]:
            return "user"
        elif self.card_points[user_bid] < self.card_points[bot_bid]:
            return "bot"
        else:
            return "tie"
