# main.py
import pygame
from pygame_ui import PygameUI
from strategy import Strategy
from gameplay import Gameplay

def main():
    WINDOW_WIDTH = 1200
    WINDOW_HEIGHT = 700
    CARD_WIDTH = 60
    CARD_HEIGHT = 70
    CARD_SPACING = 20
    FONT_SIZE = 30
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    GRAY = (200, 200, 200)
    rounds = 13
    user_cards = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    
    ui = PygameUI(WINDOW_WIDTH, WINDOW_HEIGHT, CARD_WIDTH, CARD_HEIGHT, CARD_SPACING, FONT_SIZE)
    gameplay = Gameplay(rounds, user_cards)
    strategy = Strategy()
    
    running = True
    while running and gameplay.current_round <= rounds:
        ui.clear_screen()
        
        if gameplay.current_round == 1 and not gameplay.drawn_cards:
            drawn_card = gameplay.draw_card()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                start_x = (WINDOW_WIDTH - (CARD_WIDTH + CARD_SPACING) * len(gameplay.user_cards)) // 2
                for i, card in enumerate(gameplay.user_cards):
                    card_rect = pygame.Rect(start_x + i * (CARD_WIDTH + CARD_SPACING), WINDOW_HEIGHT - CARD_HEIGHT - CARD_SPACING, CARD_WIDTH, CARD_HEIGHT)
                    if card_rect.collidepoint(mouse_x, mouse_y):
                        if card not in gameplay.user_bids:
                            gameplay.user_bids.append(card)
                        else:
                            continue
                        if drawn_card:
                            gameplay.bot_bids.append(strategy.make_bot_bid(gameplay.bot_bids, drawn_card))
                            
                        winner = gameplay.determine_winner(gameplay.user_bids[-1], gameplay.bot_bids[-1], drawn_card)
                        if winner == "user":
                            gameplay.user_points += gameplay.card_points[drawn_card]
                        elif winner == "bot":
                            gameplay.bot_points += gameplay.card_points[drawn_card]
                        gameplay.current_round += 1
                        drawn_card = gameplay.draw_card()

                        if gameplay.current_round <= rounds:
                            for i in range(4, 0, -1):
                                ui.clear_screen()
                                ui.display_text(f"Round: {gameplay.current_round}/{rounds}", 20, 20, BLACK)
                                ui.display_text(f"Your Bid: {gameplay.user_bids[-1]}", 40, WINDOW_HEIGHT - 120, BLACK)
                                ui.display_text(f"Bot's Bid: {gameplay.bot_bids[-1]}", WINDOW_WIDTH - 180, WINDOW_HEIGHT - 120, BLACK)
                                ui.display_text(f"Winner: {winner}", WINDOW_WIDTH // 2 - 50, WINDOW_HEIGHT // 2, BLACK)
                                ui.display_text(f"Your Score: {gameplay.user_points}", 40, WINDOW_HEIGHT - 160, BLACK)
                                ui.display_text(f"Bot's Score: {gameplay.bot_points}", WINDOW_WIDTH - 180, WINDOW_HEIGHT - 160, BLACK)
                                ui.display_text(f"Next Round Starting in {i}...", WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 - 100, BLACK)
                                ui.update_display()
                                ui.wait(1000)
                        ui.clear_screen()

        ui.display_text(f"Round: {gameplay.current_round}/{rounds}", 20, 20, BLACK)
        ui.display_cards(gameplay.user_cards, gameplay.user_bids)
        ui.display_diamond_card(drawn_card)
        ui.display_text(f"Your Score: {gameplay.user_points}", 40, WINDOW_HEIGHT - 160, BLACK)
        ui.display_text(f"Bot's Score: {gameplay.bot_points}", WINDOW_WIDTH - 180, WINDOW_HEIGHT - 160, BLACK)
        ui.update_display()

    ui.quit()

if __name__ == "__main__":
    main()
