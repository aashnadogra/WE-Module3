# pygame_ui.py
import pygame

class PygameUI:
    def __init__(self, window_width, window_height, card_width, card_height, card_spacing, font_size):
        pygame.init()
        self.window_width = window_width
        self.window_height = window_height
        self.card_width = card_width
        self.card_height = card_height
        self.card_spacing = card_spacing
        self.font_size = font_size
        self.screen = pygame.display.set_mode((self.window_width, self.window_height))
        pygame.display.set_caption("Diamonds Game")
        self.font = pygame.font.Font(None, self.font_size)
        
    def draw_rect(self, color, x, y, width, height):
        pygame.draw.rect(self.screen, color, (x, y, width, height))
        
    def display_text(self, text, x, y, color):
        text_surface = self.font.render(text, True, color)
        self.screen.blit(text_surface, (x, y))
        
    def display_cards(self, cards, user_bids):
        x = (self.window_width - (self.card_width + self.card_spacing) * len(cards)) // 2
        y = self.window_height - self.card_height - self.card_spacing
        for card in cards:
            color = (0, 0, 0)
            if card in user_bids:
                color = (255, 0, 0)
            self.draw_rect((200, 200, 200), x, y, self.card_width, self.card_height)
            self.display_text(card, x + self.card_width // 2, y + self.card_height // 2, color)
            x += self.card_width + self.card_spacing
            
    def update_display(self):
        pygame.display.flip()
        
    def clear_screen(self):
        self.screen.fill((255, 255, 255))
        
    def wait(self, milliseconds):
        pygame.time.wait(milliseconds)
        
    def quit(self):
        pygame.quit()

    def display_diamond_card(self, card):
        x = (self.window_width) // 2
        y = self.window_height // 2
        pygame.draw.rect(self.screen, (200, 200, 200), (x, y, self.card_width, self.card_height))
        self.display_text(card, x + self.card_width // 2, y + self.card_height // 2, (0, 0, 0))
