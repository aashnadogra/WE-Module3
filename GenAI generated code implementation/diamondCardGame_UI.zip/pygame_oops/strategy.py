# strategy.py
import random

class Strategy:
    @staticmethod
    def make_bot_bid(bot_bids, drawn_card):
        diamonds = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        if drawn_card in ['2', '3', '4', '5']:
            bot_bid = random.choice(['2', '3', '4', '5'])
        elif drawn_card in ['6', '7', '8', '9']:
            bot_bid = random.choice(['6', '7', '8', '9'])
        else:
            bot_bid = random.choice(['10', 'J', 'Q', 'K', 'A'])

        if bot_bid in bot_bids:
            return Strategy.make_bot_bid(bot_bids, drawn_card)
        else:
            bot_bids.append(bot_bid)
            return bot_bid
